package br.com.caelum.vraptor.sysweb.enums;

/**
 * @author Fidelis
 *
 */
public enum MedidaEnum {
	ML, GOTAS, MG, CAPSULA;
}
