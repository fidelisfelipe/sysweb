package br.com.caelum.vraptor.sysweb.dao;

public interface UsuarioDao {

}
