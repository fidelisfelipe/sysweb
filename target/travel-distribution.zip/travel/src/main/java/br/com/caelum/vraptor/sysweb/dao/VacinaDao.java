package br.com.caelum.vraptor.sysweb.dao;


/**
 * @author fidelis.guimaraes
 *
 */
public interface VacinaDao {
	
}
