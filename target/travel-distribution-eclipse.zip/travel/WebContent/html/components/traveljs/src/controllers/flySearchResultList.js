/**
 * Ctrl Filter Top
 **/

controllers.controller('fly-search-result-filter-top-selector', [nameVarInject, setListSearchResultFilterTop]);
function setListSearchResultFilterTop(scope){
	console.log("fly-search-result-filter-top-selector");
	scope.isList = true;
}