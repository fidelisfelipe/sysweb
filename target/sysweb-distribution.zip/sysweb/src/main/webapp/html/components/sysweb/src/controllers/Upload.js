
	/**
	 * Ctrl Upload
	 **/

	controllers.controller('upload-ctrl', [nameVarInject, setAccountCtrl]);
	function setUploadCtrl(scope){
		console.log('upload-ctrl');
		scope.title = 'Upload';
	}
	