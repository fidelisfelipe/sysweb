var Menu = require('../src/controllers/Menu');

describe("Menu", function(){
  var menu;

  beforeEach(function(){
    menu = new Menu();
  });

  it("should be return languages to Menu", function(){
     
  });

});