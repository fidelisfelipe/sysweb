package br.com.caelum.vraptor.sysweb.dao;

/**
 * @author Fidelis
 *
 */
public interface UsuarioDao {

}
