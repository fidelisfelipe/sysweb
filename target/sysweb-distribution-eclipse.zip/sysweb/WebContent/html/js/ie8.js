/*
 * Title:   Travelo | Responsive HTML5 Travel Template - IE8 Javascript
 * Author:  http://themeforest.net/user/soaptheme
 */